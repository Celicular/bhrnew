import { Instagram, Facebook, Twitter, Mail } from 'lucide-react';
import logo from 'figma:asset/06378ae553d030967dca1b29862dd8f35b7a96ba.png';

const footerLinks = {
  company: [
    { label: 'About Us', href: '#about' },
    { label: 'How It Works', href: '#' },
    { label: 'Careers', href: '#' },
    { label: 'Press', href: '#' },
  ],
  hosting: [
    { label: 'List Your Property', href: '#host' },
    { label: 'Host Resources', href: '#' },
    { label: 'Community Forum', href: '#' },
    { label: 'Host Insurance', href: '#' },
  ],
  support: [
    { label: 'Help Center', href: '#support' },
    { label: 'Contact Us', href: '#' },
    { label: 'Trust & Safety', href: '#' },
    { label: 'Cancellation Policy', href: '#' },
  ],
  discover: [
    { label: 'Beach Rentals', href: '#' },
    { label: 'Mountain Cabins', href: '#' },
    { label: 'City Apartments', href: '#' },
    { label: 'Event Properties', href: '#' },
  ],
};

const socialLinks = [
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Mail, href: '#', label: 'Email' },
];

export function Footer() {
  return (
    <footer className="bg-[#1a1f2e] text-[#c5c3bd] pt-24 pb-12 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-6">
            <img
              src={logo}
              alt="Book Holiday Rental"
              className="h-12 w-auto brightness-0 invert"
            />
            <p className="text-[#9baab8] font-light leading-relaxed max-w-sm">
              Your trusted partner for exceptional vacation rentals across the United States. Discover, book, and experience unforgettable stays.
            </p>
            
            {/* Newsletter */}
            <div className="pt-4">
              <p className="text-sm text-[#d4af37] uppercase tracking-wider mb-4">
                Stay Updated
              </p>
              <div className="flex gap-3">
                <input
                  type="email"
                  placeholder="Your email"
                  className="flex-1 px-5 py-3 rounded-full bg-white/5 border border-white/10 focus:border-[#d4af37]/50 outline-none text-[#faf8f5] placeholder:text-[#9baab8] transition-colors duration-300"
                />
                <button className="px-6 py-3 rounded-full bg-[#d4af37] hover:bg-[#c9a532] text-[#1a1f2e] transition-colors duration-300 font-medium">
                  Subscribe
                </button>
              </div>
            </div>
          </div>

          {/* Links Columns */}
          <div>
            <h4 className="text-[#faf8f5] mb-6 uppercase tracking-wider text-sm font-medium">Company</h4>
            <ul className="space-y-4">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-[#9baab8] hover:text-[#d4af37] transition-colors duration-300 text-sm"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[#faf8f5] mb-6 uppercase tracking-wider text-sm font-medium">Hosting</h4>
            <ul className="space-y-4">
              {footerLinks.hosting.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-[#9baab8] hover:text-[#d4af37] transition-colors duration-300 text-sm"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-[#faf8f5] mb-6 uppercase tracking-wider text-sm font-medium" id="support">Support</h4>
            <ul className="space-y-4">
              {footerLinks.support.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-[#9baab8] hover:text-[#d4af37] transition-colors duration-300 text-sm"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-white/10 to-transparent mb-12" />

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          {/* Copyright */}
          <div className="text-sm text-[#9baab8]">
            © 2026 Book Holiday Rental. All rights reserved.
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-4">
            {socialLinks.map((social) => (
              <a
                key={social.label}
                href={social.href}
                aria-label={social.label}
                className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-[#d4af37]/10 hover:border-[#d4af37]/30 transition-all duration-300 group"
              >
                <social.icon className="w-5 h-5 text-[#9baab8] group-hover:text-[#d4af37] transition-colors duration-300" />
              </a>
            ))}
          </div>

          {/* Legal Links */}
          <div className="flex items-center gap-6 text-sm text-[#9baab8]">
            <a href="#" className="hover:text-[#d4af37] transition-colors duration-300">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-[#d4af37] transition-colors duration-300">
              Terms of Service
            </a>
            <a href="#" className="hover:text-[#d4af37] transition-colors duration-300">
              Sitemap
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
