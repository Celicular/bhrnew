import { motion } from 'motion/react';
import { Calendar, Sparkles, MapPin } from 'lucide-react';

const events = [
  {
    id: 1,
    title: 'FIFA World Cup 2026',
    category: 'Sports Event',
    date: 'June - July 2026',
    location: 'Multiple US Cities',
    image: 'https://images.unsplash.com/photo-1760550818632-ccaad94c859f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleGNsdXNpdmUlMjBzcG9ydHMlMjBldmVudHxlbnwxfHx8fDE3NjkwNzQ2MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Stay near stadiums in New York, Los Angeles, Miami & more',
    properties: 234,
  },
  {
    id: 2,
    title: 'Summer Beach Getaways',
    category: 'Seasonal Collection',
    date: 'June - August 2026',
    location: 'Coastal USA',
    image: 'https://images.unsplash.com/photo-1729708790802-1993d6f5634d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcml2YXRlJTIwaXNsYW5kJTIwcmVzb3J0fGVufDF8fHx8MTc2OTA3NDYxNnww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Beachfront homes from California to the Carolinas',
    properties: 567,
  },
  {
    id: 3,
    title: "New Year's Eve Luxury Stays",
    category: 'Holiday Special',
    date: 'December 31, 2025',
    location: 'Major US Cities',
    image: 'https://images.unsplash.com/photo-1740482881694-d72f4e4cc47e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB5YWNodCUyMHN1bnNldHxlbnwxfHx8fDE3NjkwNjg4NDF8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Ring in the new year with spectacular city views',
    properties: 189,
  },
  {
    id: 4,
    title: 'Winter Ski Retreats',
    category: 'Seasonal Event',
    date: 'December 2025 - March 2026',
    location: 'Colorado, Utah & Vermont',
    image: 'https://images.unsplash.com/photo-1709508496457-e2f9c42493c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBtb3VudGFpbiUyMGNoYWxldHxlbnwxfHx8fDE3NjkwNzQ2MTd8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Ski-in/ski-out chalets & mountain lodges',
    properties: 312,
  },
];

export function ExclusiveEvents() {
  return (
    <section className="py-32 px-6 bg-[#1a1f2e] relative overflow-hidden">
      {/* Subtle Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, #d4af37 1px, transparent 0)`,
          backgroundSize: '48px 48px'
        }} />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mb-20"
        >
          <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/20 mb-6">
            <Sparkles className="w-5 h-5 text-[#d4af37]" />
            <span className="text-sm text-[#d4af37] uppercase tracking-wider">Special Collections</span>
          </div>
          <h2 className="text-5xl md:text-6xl text-[#faf8f5] mb-4">
            Exclusive Experiences
          </h2>
          <p className="text-lg text-[#9baab8] max-w-2xl mx-auto font-light">
            Book your stay for major events and seasonal celebrations
          </p>
        </motion.div>

        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {events.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.15, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="group relative overflow-hidden rounded-[2rem] cursor-pointer">
                {/* Image Container */}
                <div className="aspect-[16/10] overflow-hidden bg-[#2a3142]">
                  <img
                    src={event.image}
                    alt={event.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[rgba(26,31,46,0.95)] via-[rgba(26,31,46,0.4)] to-transparent" />
                </div>

                {/* Content */}
                <div className="absolute inset-x-0 bottom-0 p-8">
                  {/* Category Badge */}
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full backdrop-blur-md bg-white/10 border border-white/20 mb-4">
                    <span className="text-xs text-[#d4af37] uppercase tracking-wider">{event.category}</span>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-3xl text-[#faf8f5] mb-3 transform transition-transform duration-500 group-hover:translate-y-[-4px]">
                    {event.title}
                  </h3>
                  <p className="text-[#c5c3bd] mb-4 font-light">
                    {event.description}
                  </p>

                  {/* Date & Location */}
                  <div className="flex flex-col gap-2 mb-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-[#d4af37]" />
                      <span className="text-sm text-[#9baab8]">{event.date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-[#d4af37]" />
                      <span className="text-sm text-[#9baab8]">{event.location}</span>
                    </div>
                  </div>

                  {/* CTA Button */}
                  <button className="w-full mt-4 px-6 py-3 rounded-full bg-[#d4af37] hover:bg-[#c9a532] text-[#1a1f2e] transition-all duration-300 flex items-center justify-between group-hover:shadow-lg group-hover:shadow-[#d4af37]/20">
                    <span className="font-medium">View {event.properties} Properties</span>
                    <svg className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                  </button>
                </div>

                {/* Hover Shine Effect */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#d4af37]/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}