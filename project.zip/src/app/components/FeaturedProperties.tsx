import { useState } from 'react';
import { Star, MapPin, Users, Bed, Bath, Heart, Wind, Home, BookOpen } from 'lucide-react';
import { motion } from 'motion/react';

const properties = [
  {
    id: 1,
    name: 'Newark Retreat w/ Home Gym, Grill, Bicycles + More',
    location: 'Alameda, California',
    image: 'https://images.unsplash.com/photo-1634736794027-3297ad344057?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYW50b3JpbmklMjBncmVlY2UlMjBsdXh1cnl8ZW58MXx8fHwxNzY5MDAzNTg5fDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.9,
    reviews: 127,
    price: 432,
    guests: 6,
    bedrooms: 3,
    bathrooms: 3,
    amenities: ['Air Conditioning', 'Balcony', 'Books'],
  },
  {
    id: 2,
    name: 'Beachfront Paradise with Ocean Views',
    location: 'Malibu, California',
    image: 'https://images.unsplash.com/photo-1614505241347-7f4765c1035e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxkaXZlcyUyMHJlc29ydCUyMGx1eHVyeXxlbnwxfHx8fDE3NjkwNjc4Mjl8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 5.0,
    reviews: 203,
    price: 850,
    guests: 8,
    bedrooms: 4,
    bathrooms: 3,
    amenities: ['Air Conditioning', 'Pool', 'Beach Access'],
  },
  {
    id: 3,
    name: 'Modern Downtown Loft with City Skyline',
    location: 'Miami, Florida',
    image: 'https://images.unsplash.com/photo-1728050829092-acd5cc835d5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWxpJTIwbHV4dXJ5JTIwdmlsbGF8ZW58MXx8fHwxNzY5MDAzNTkwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.8,
    reviews: 156,
    price: 395,
    guests: 4,
    bedrooms: 2,
    bathrooms: 2,
    amenities: ['Air Conditioning', 'Gym', 'Parking'],
  },
  {
    id: 4,
    name: 'Mountain Chalet with Hot Tub & Fireplace',
    location: 'Aspen, Colorado',
    image: 'https://images.unsplash.com/photo-1738260530641-f945fa20a6cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkdWJhaSUyMGx1eHVyeSUyMGhvdGVsfGVufDF8fHx8MTc2OTA3NDYxNXww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 4.9,
    reviews: 189,
    price: 675,
    guests: 6,
    bedrooms: 3,
    bathrooms: 2,
    amenities: ['Hot Tub', 'Fireplace', 'Ski Access'],
  },
];

const amenityIcons: Record<string, any> = {
  'Air Conditioning': Wind,
  'Balcony': Home,
  'Books': BookOpen,
  'Pool': Users,
  'Beach Access': MapPin,
  'Gym': Users,
  'Parking': Home,
  'Hot Tub': Wind,
  'Fireplace': Home,
  'Ski Access': MapPin,
};

export function FeaturedProperties() {
  const [favorites, setFavorites] = useState<number[]>([]);

  const toggleFavorite = (id: number) => {
    setFavorites(prev =>
      prev.includes(id) ? prev.filter(fav => fav !== id) : [...prev, id]
    );
  };

  return (
    <section className="py-32 px-6 bg-[#faf8f5]" id="inspiration">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl text-[#1a1f2e] mb-4">
            Featured Collection
          </h2>
          <p className="text-lg text-[#6b7280] max-w-2xl mx-auto font-light">
            Handpicked vacation homes across the United States
          </p>
        </motion.div>

        {/* Properties Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {properties.map((property, index) => (
            <motion.div
              key={property.id}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.1, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="group cursor-pointer">
                {/* Image Container */}
                <div className="relative overflow-hidden rounded-[2rem] mb-6 shadow-xl hover:shadow-2xl transition-shadow duration-500">
                  <div className="aspect-[4/3] overflow-hidden">
                    <img
                      src={property.image}
                      alt={property.name}
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[rgba(26,31,46,0.6)] via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  
                  {/* Rating Badge */}
                  <div className="absolute top-6 left-6 backdrop-blur-md bg-white/90 px-4 py-2 rounded-full flex items-center gap-2 shadow-lg">
                    <Star className="w-4 h-4 fill-[#d4af37] text-[#d4af37]" />
                    <span className="text-sm font-medium text-[#1a1f2e]">{property.rating}</span>
                  </div>

                  {/* Heart Button */}
                  <motion.button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(property.id);
                    }}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    className="absolute top-6 right-6 p-3 backdrop-blur-md bg-white/90 rounded-full shadow-lg hover:bg-white transition-all duration-300"
                  >
                    <Heart
                      className={`w-5 h-5 transition-all duration-300 ${
                        favorites.includes(property.id)
                          ? 'fill-red-500 text-red-500'
                          : 'text-[#1a1f2e]'
                      }`}
                    />
                  </motion.button>
                </div>

                {/* Property Info */}
                <div className="space-y-4">
                  <div>
                    <h3 className="text-2xl text-[#1a1f2e] mb-2 line-clamp-2">
                      {property.name}
                    </h3>
                    <div className="flex items-center gap-2 text-[#9baab8] mb-4">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{property.location}</span>
                    </div>
                  </div>

                  {/* Guests, Beds, Baths */}
                  <div className="flex items-center gap-6">
                    <div className="flex items-center gap-2 text-[#1a1f2e]">
                      <Users className="w-5 h-5 text-[#d4af37]" />
                      <span className="text-sm">{property.guests} guests</span>
                    </div>
                    <div className="flex items-center gap-2 text-[#1a1f2e]">
                      <Bed className="w-5 h-5 text-[#d4af37]" />
                      <span className="text-sm">{property.bedrooms} beds</span>
                    </div>
                    <div className="flex items-center gap-2 text-[#1a1f2e]">
                      <Bath className="w-5 h-5 text-[#d4af37]" />
                      <span className="text-sm">{property.bathrooms} baths</span>
                    </div>
                  </div>

                  {/* Amenities */}
                  <div className="flex flex-wrap gap-2">
                    {property.amenities.map((amenity) => {
                      const Icon = amenityIcons[amenity] || Home;
                      return (
                        <div
                          key={amenity}
                          className="flex items-center gap-2 px-3 py-2 rounded-full bg-[#f8f6f3] border border-[#1a1f2e]/5"
                        >
                          <Icon className="w-4 h-4 text-[#d4af37]" />
                          <span className="text-xs text-[#6b7280]">{amenity}</span>
                        </div>
                      );
                    })}
                  </div>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-[#1a1f2e]/10">
                    <div className="text-sm text-[#6b7280]">
                      {property.reviews} reviews
                    </div>
                    <div className="text-right">
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl text-[#1a1f2e]">${property.price}</span>
                        <span className="text-sm text-[#9baab8]">/night</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* See More CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className="text-center mt-16"
        >
          <button className="group relative overflow-hidden px-12 py-5 rounded-full bg-[#1a1f2e] text-[#faf8f5] hover:bg-[#2a3142] transition-all duration-500 shadow-lg hover:shadow-xl">
            <span className="relative z-10">See More Properties</span>
            <div className="absolute inset-0 bg-gradient-to-r from-[#d4af37]/0 via-[#d4af37]/10 to-[#d4af37]/0 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700" />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
